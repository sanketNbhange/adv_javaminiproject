package com.grievance.service;

import java.util.List;

import com.grievance.dao.AdminDao;
import com.grievance.dao.AdminDaoImpl;
import com.grievance.dto.DepartmentHeadDto;
import com.grievance.model.Department;

public class AdminService implements AdminI {

	AdminDao adminDao=new AdminDaoImpl();
	@Override
	public List<Department> getAllDepartment() throws Exception {
		return adminDao.getAllDepartment();
		
	}
	@Override
	public List<DepartmentHeadDto> getAllDepartmentInfo() throws Exception {
		return new AdminDaoImpl().getAllDepartmentInfo();
	}

}
