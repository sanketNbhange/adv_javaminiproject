package com.grievance.dto;

import java.time.LocalDate;
import java.util.Arrays;

public class ComplaintDto {
	private String complaintid;
	private String name;
	private String email;
	 private String complaintmsg;
	 private byte[] screenshot;
	 private LocalDate complaintdate;
	 private  int updatecount;
	public ComplaintDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ComplaintDto(String complaintid, String name, String email, String complaintmsg, byte[] screenshot,
			LocalDate complaintdate, int updatecount) {
		super();
		this.complaintid = complaintid;
		this.name = name;
		this.email = email;
		this.complaintmsg = complaintmsg;
		this.screenshot = screenshot;
		this.complaintdate = complaintdate;
		this.updatecount = updatecount;
	}
	public String getComplaintid() {
		return complaintid;
	}
	public void setComplaintid(String complaintid) {
		this.complaintid = complaintid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getComplaintmsg() {
		return complaintmsg;
	}
	public void setComplaintmsg(String complaintmsg) {
		this.complaintmsg = complaintmsg;
	}
	public byte[] getScreenshot() {
		return screenshot;
	}
	public void setScreenshot(byte[] screenshot) {
		this.screenshot = screenshot;
	}
	public LocalDate getComplaintdate() {
		return complaintdate;
	}
	public void setComplaintdate(LocalDate complaintdate) {
		this.complaintdate = complaintdate;
	}
	public int getUpdatecount() {
		return updatecount;
	}
	public void setUpdatecount(int updatecount) {
		this.updatecount = updatecount;
	}
	@Override
	public String toString() {
		return "ComplaintDto [complaintid=" + complaintid + ", name=" + name + ", email=" + email + ", complaintmsg="
				+ complaintmsg + ", screenshot=" + Arrays.toString(screenshot) + ", complaintdate=" + complaintdate
				+ ", updatecount=" + updatecount + "]";
	}	 

}
