package com.grievance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.grievance.dbutil.DbUtil;
import com.grievance.model.Complaint;
import com.grievance.model.Department;

public class DepartDaoimpl implements DepartmentDao {

	public int addDepartment(Department department) throws Exception {
		String query = "INSERT INTO department (`deptid`, `deptname`, `userid`) VALUES (?, ?, ?);";
		System.out.println(department.toString());
		Connection con = DbUtil.getConnection();
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1, department.getDeptId());
		ps.setString(2, department.getDeptName());
		ps.setString(3, department.getUserId());
		 return ps.executeUpdate();
	}
	@Override
	public int deleteDepartment(String deptId) throws Exception {
		String sql = "delete from department where deptid = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);		
		ps.setString(1, deptId);			
		return ps.executeUpdate();
	}
	
	@Override
	public int updateDepartment(Department department) throws Exception {
		String query = "update department set deptname= ?, userid=? where deptid = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(query);		
		ps.setString(1, department.getDeptName());
		ps.setString(2, department.getUserId());
		ps.setString(3, department.getDeptId());
		return ps.executeUpdate();
	}

	public List<Complaint> getAllComplaint() throws Exception {
		String sql = "SELECT * FROM complaint";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		List<Complaint> complaints = new ArrayList<Complaint>();
		while (rs.next()) {
			
			complaints.add(new Complaint(rs.getString(1), rs.getString(1), rs.getBytes(3), rs.getInt(4),
					rs.getDate(5).toLocalDate(), rs.getDate(6).toLocalDate(), rs.getString(7), rs.getString(1), 
					rs.getString(1),  rs.getDate(6).toLocalDate(), rs.getString(1), rs.getString(1), rs.getString(1)));
		}
		return complaints;
	}
	
	
	@Override
	public int updateDeptRemark(String complaintId, String message) throws Exception {
		String sql = "UPDATE complaint SET complaintmsg = ? where complaintid = ? " ;
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, message);
		ps.setString(2, complaintId);
		return ps.executeUpdate();
	}
	
	@Override
	public int updateStatus(String complaintId, String status) throws Exception {
		String sql = "UPDATE complaint SET complaintstatus = ? where complaintid = ? " ;
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, status);
		ps.setString(2, complaintId);
		return ps.executeUpdate();
	}
	
	
	@Override
	public int transferComplaint(String complaintId, String deptId) throws Exception {
		String sql = "UPDATE complaint SET deptid = ? WHERE  complaintid = ? " ;
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, deptId);
		ps.setString(2, complaintId);
		return ps.executeUpdate();
	}
	
	@Override
	public Department getDepartmentById(String deptId) throws Exception {
		String query="select * from department where deptid = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setString(1, deptId);
		ResultSet rs = ps.executeQuery();
		Department department=null;
		if(rs.next()) {
		department = new Department(rs.getString(1), rs.getString(2), rs.getString(3));
		}
		return department;
	}

}
