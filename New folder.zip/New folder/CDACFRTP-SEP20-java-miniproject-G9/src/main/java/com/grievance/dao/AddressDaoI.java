package com.grievance.dao;

import com.grievance.model.Address;

public interface AddressDaoI {

	public int addAddress(Address address) throws Exception;
}
