package com.grievance.dao;

import java.util.List;

import com.grievance.model.Complaint;
import com.grievance.model.Department;

public interface DepartmentDao {

	public int addDepartment(Department department) throws Exception;
	public int deleteDepartment(String deptId) throws Exception;
	public int updateDepartment(Department department) throws Exception;

	public List<Complaint> getAllComplaint() throws Exception;
	public int updateDeptRemark(String complaintId, String message) throws Exception;
	public int updateStatus(String complaintId, String status) throws Exception;
	public int transferComplaint(String complaintId, String deptId) throws Exception;

	public Department getDepartmentById(String deptId) throws Exception;

}
