package com.grievance.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DepartmentHeadController
 */
public class DepartmentHeadController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public DepartmentHeadController() {
     
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Inside DeptHeadC");
		String path = request.getPathInfo();
		if (path.equals("/getAllComplaints")) {
			System.out.println("inside getAllComplaints ");
			
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		
	}

}
