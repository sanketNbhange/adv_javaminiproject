package com.grievance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.grievance.dbutil.DbUtil;
import com.grievance.dto.DepartmentHeadDto;
import com.grievance.model.Department;

public class AdminDaoImpl implements AdminDao {

	public int addDepartment(Department department) throws Exception {
		String sql = "INSERT INTO department values(?,?,?)";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, department.getDeptId());
		ps.setString(2, department.getDeptName());
		ps.setString(3, department.getUserId());
		return ps.executeUpdate();
	
	}

	public List<Department> getAllDepartment() throws Exception {
		String sql = "SELECT * FROM department";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		List<Department> departments = new ArrayList<Department>();
		while (rs.next()) {
			departments.add(new Department(rs.getString(1),rs.getString(2),rs.getString(3)));
		}
		return departments;
	}

	@Override
	public List<DepartmentHeadDto> getAllDepartmentInfo() throws Exception {
		String sql = "SELECT department.deptname , IFNULL( user.name , \"NA\") as head, IFNULL( user.email , \"NA\") as email ,department.deptid\r\n"
				+ "from department \r\n"
				+ "left outer join user on user.userid = department.userid";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		List<DepartmentHeadDto> departmentInfo = new ArrayList<DepartmentHeadDto>();
		while (rs.next()) {
			departmentInfo.add(new DepartmentHeadDto(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)));
		}
		return departmentInfo;
	}

}
