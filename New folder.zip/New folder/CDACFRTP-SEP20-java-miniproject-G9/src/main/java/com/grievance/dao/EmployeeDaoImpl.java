package com.grievance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.grievance.dbutil.DbUtil;
import com.grievance.model.Complaint;
import com.grievance.model.Role;
import com.grievance.model.User;

public class EmployeeDaoImpl implements EmployeeDaoI {

	public User getUserByName(String name) throws Exception {
		String query = "SELECT * FROM user where  name= ?";
		Connection con = DbUtil.getConnection();
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1, name);
		ResultSet rs = ps.executeQuery();
		User  user = null;
		if(rs.next()) {
			user = new User(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
		}
		System.out.println(user.toString());
		return user;
	}

	public int addEmployee(User user) throws Exception {
		String query  = "INSERT INTO user values(?,?,?,?,?,?)";
		Connection con = DbUtil.getConnection();
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1, user.getUserId());
		ps.setString(2, user.getName());
		ps.setString(3, user.getEmail());
		ps.setString(4, user.getMobileNo());
		ps.setString(5, user.getPassword());
		ps.setString(6, user.getRole());
		return ps.executeUpdate();
	}
	
	@Override
	public List<User> getAllFreeDeptHead() throws Exception {
		String role = Role.DEPARTMENTHEAD.toString();
		String query = "select * FROM user where role = ? and user.userid not in (select userid from department where userid is not null);";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(query);
		ps.setString(1, role);
		ResultSet rs = ps.executeQuery();
		List<User> userList = new ArrayList<User>();
		while(rs.next()) {
			userList.add(new User(rs.getString(1), rs.getString(2), 
					rs.getString(3), rs.getString(4),
					rs.getString(5), rs.getString(6)));
		}
		System.out.println(userList);
		return userList;
	}
	
	@Override
	public List<Complaint> getAllComplaintById(String deptid) throws Exception {
		String sql = "SELECT * FROM complaint where deptid = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, deptid);
		ResultSet rs = ps.executeQuery();

		List<Complaint> complaints = new ArrayList<Complaint>();
		while (rs.next()) {
			
			complaints.add(new Complaint(rs.getString(1), rs.getString(2), rs.getBytes(3), rs.getInt(4),
					rs.getDate(5).toLocalDate(), rs.getDate(6).toLocalDate(), rs.getString(7), rs.getString(8), 
					rs.getString(9),  rs.getDate(10).toLocalDate(), rs.getString(11), rs.getString(12), rs.getString(13)));
		}
		return complaints;
	}
}