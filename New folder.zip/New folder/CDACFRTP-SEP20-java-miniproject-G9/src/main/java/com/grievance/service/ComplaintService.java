package com.grievance.service;

import java.time.LocalDate;

import javax.swing.RowFilter.ComparisonType;

import com.grievance.dao.ComplaintDaoI;
import com.grievance.dao.ComplaintDaoImpl;
import com.grievance.model.Complaint;
import com.grievance.model.ComplaintStatus;

public class ComplaintService implements ComplaintI{

	ComplaintDaoI complaintDao = new ComplaintDaoImpl();
	public static LocalDate getCurrentDate() {
		LocalDate dt = LocalDate.now(); 
		return dt ;
	}

//	@Override
//	public String addComplaint(String complaintMsg, byte[] docs, LocalDate complaintDate) throws Exception {
//		Complaint complaint  = null;
//		complaint.setComplaintMsg(complaintMsg);
//		complaint.setDocs(docs);
//		complaint.setComplaintDate(getCurrentDate());
//		int status = complaintDao.registerComplaint(complaint);
//		if(status == 1)
//		{
//			return complaintMsg;
//		}
//		else
//		{
//			throw new Exception("Cannot register compalint please try again");
//		}
//	}



	@Override
	public String addComplaint(String complaintMsg, byte[] docs, String deptId) throws Exception {
		Complaint complaint  = new Complaint();
		complaint.setComplaintId( "C"+ Math.round(Math.random()*999));
		complaint.setComplaintMsg(complaintMsg);
		complaint.setDocs(docs);
		complaint.setComplaintDate(getCurrentDate());
		complaint.setDeptId(deptId);
		complaint.setComplaintStatus(ComplaintStatus.PENDING.toString());
		
		int status = complaintDao.registerComplaint(complaint);
		if(status == 1)
		{
			return complaintMsg;
		}
		else
		{
			throw new Exception("Cannot register compalint please try again");
		}
	}
}
