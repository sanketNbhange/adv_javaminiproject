package com.grievance.dao;

import java.util.List;

import com.grievance.dto.DepartmentHeadDto;
import com.grievance.model.Department;

public interface AdminDao {
   public int addDepartment(Department department) throws Exception;
   public List<Department> getAllDepartment() throws Exception;
   public List<DepartmentHeadDto> getAllDepartmentInfo() throws Exception;

}
