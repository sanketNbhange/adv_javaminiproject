package com.grievance.dao;

import java.util.List;

import com.grievance.dto.ComplaintDto;
import com.grievance.model.Complaint;

public interface ComplaintDaoI {
	public int registerComplaint(Complaint complaint) throws Exception;
	public List<ComplaintDto> getAllComplaintByDeptId(String deptid) throws Exception;
	
}
