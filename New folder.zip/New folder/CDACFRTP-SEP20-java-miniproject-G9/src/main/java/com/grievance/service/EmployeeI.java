package com.grievance.service;

import java.util.List;

import com.grievance.dto.ComplaintDto;
import com.grievance.model.User;

public interface EmployeeI {
	public String registerEmployee(String name, String email, String password,
			String mobileNo, String role)
			throws Exception;

	public List<User> getAllFreeDeptHead() throws Exception;
	public List<ComplaintDto> getAllComplaintsBtDeptId(String deptid) throws Exception;
	
}
