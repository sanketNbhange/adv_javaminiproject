package com.grievance.dto;

public class DepartmentHeadDto {
	 private String deptname;
	 private String head;
	 private String email;
	 private String deptid;
	 
	public DepartmentHeadDto() {
		super();
	}

	public DepartmentHeadDto(String deptname, String head, String email, String deptid) {
		super();
		this.deptname = deptname;
		this.head = head;
		this.email = email;
		this.deptid = deptid;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public String getHead() {
		return head;
	}

	public void setHead(String head) {
		this.head = head;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDeptid() {
		return deptid;
	}

	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}

	@Override
	public String toString() {
		return "DepartmentHeadDto [deptname=" + deptname + ", head=" + head + ", email=" + email + ", deptid=" + deptid
				+ "]";
	}

}
