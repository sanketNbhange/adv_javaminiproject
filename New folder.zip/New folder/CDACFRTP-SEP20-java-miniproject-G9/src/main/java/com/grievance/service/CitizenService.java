package com.grievance.service;

import java.util.List;

import com.grievance.dao.AddressDaoI;
import com.grievance.dao.AddressDaoImpl;
import com.grievance.dao.CitizenDaoI;
import com.grievance.dao.CitizenDaoImpl;
import com.grievance.model.Address;
import com.grievance.model.Complaint;
import com.grievance.model.Role;
import com.grievance.model.User;

public class CitizenService implements CitizenI {

	CitizenDaoI citizenDao = new CitizenDaoImpl();
	AddressDaoI addressDao = new AddressDaoImpl();
	public String registerCitizen(String name, String email, String password, String mobileNo, String houseNo, String landMark, String pincode) throws Exception {
		System.out.println("aaaaaa");

		User user = new User(UserI.userId, name, email, password, mobileNo, Role.CITIZEN.toString());
		String userId = citizenDao.addCitizen(user);
		Address address = new Address(AddressI.addressId, houseNo, landMark, pincode, userId);
		int addressStatus = addressDao.addAddress(address);
		if(addressStatus == 1)
		{ 
			return landMark;
		}
		else {
			throw new Exception("could not create user please try again");
		}
	}
	@Override
	public List<Complaint> getAllCitizenComplaints(String userId) throws Exception {
		
		return citizenDao.getAllCitizenComplaint(userId);
	}
}
