package com.grievance.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.grievance.dto.DepartmentHeadDto;
import com.grievance.model.Department;
import com.grievance.model.User;
import com.grievance.service.AdminI;
import com.grievance.service.AdminService;
import com.grievance.service.DepartmentI;
import com.grievance.service.DepartmentService;
import com.grievance.service.EmployeeService;

public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EmployeeService empService=new EmployeeService();
	DepartmentI deptService=new DepartmentService();
	AdminI adminService=new AdminService();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getPathInfo();
		System.out.println(path);
		if(path.equals("/addemployee")) {			
			try {
				
				System.out.println("DDDDDDDDDDDDDDDDDD");
				String name = request.getParameter("name");
				String email = request.getParameter("email");
				String password = request.getParameter("password");
				String mobileNumber = request.getParameter("mobileNo");
				String role=request.getParameter("role");
				empService.registerEmployee(name, email, password, mobileNumber, role);
				response.sendRedirect("/GrievanceSyatem/index.jsp");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(path.equals("/adddept")) {			
			try {
//				Department department = new Department();
//				department.setDeptName(request.getParameter("deptName"));

				System.out.println("inside AdminController ");
				List<User> list=new ArrayList<>();
				list=empService.getAllFreeDeptHead();
				System.out.println(list);
				request.setAttribute("allEmployees", list);
				String deptName=request.getParameter("deptname");
				String username=request.getParameter("username");
				request.getRequestDispatcher("/admin/add-dept1.jsp").forward(request, response);
				deptService.registerDepartment(deptName, username);
				response.sendRedirect("/GrievanceSyatem/index.jsp");
				//request.getRequestDispatcher("/admin/add-dept1.jsp").forward(request, response);
				
				//deptService.registerDepartment()
				//adminService.addUser(user);							
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(path.equals("/managedept")) {			
			try {
				List<Department> departments=adminService.getAllDepartment();
				List<DepartmentHeadDto> departmentInfo=adminService.getAllDepartmentInfo();
				System.out.println(departmentInfo);
				request.setAttribute("departmentInfo",departmentInfo);
				request.setAttribute("allDepartment",departments );
//				System.out.println(request.getAttribute("allDepartment"));
				request.getRequestDispatcher("/admin/manage-dept.jsp").forward(request, response);							
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(path.equals("/deletedept")) {			
			try {
				deptService.deleteDepartment(request.getParameter("deptid"));
				List<Department> departments=adminService.getAllDepartment();
				request.setAttribute("allDepartment",departments );
				System.out.println(request.getAttribute("allDepartment"));
				request.getRequestDispatcher("/admin/manage-dept.jsp").forward(request, response);						
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(path.equals("/editdept")) {			
			try {
				String deptId = request.getParameter("deptid");
				Department department=deptService.getDepartmentById(deptId);
				request.setAttribute("department", department);
				List<User> list=new ArrayList<>();
				list=empService.getAllFreeDeptHead();
				System.out.println(list);
				request.setAttribute("allEmployees", list);
				request.getRequestDispatcher("/admin/update-dept.jsp").forward(request, response);
//				String deptName = request.getParameter("deptname");
//				String userName = request.getParameter("username");
//				deptService.updateDepartment(deptName, userName, deptId);
//				System.out.println();
//				response.sendRedirect("/admin/manage-dept.jsp");						
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(path.equals("/updatedept")) {			
			try {
				System.out.println("inside update");
				String deptName = request.getParameter("deptname");
				String userName = request.getParameter("username");
				String deptId=request.getParameter("deptid");
				System.out.println("hello");
				System.out.println(deptId);
				deptService.updateDepartment(deptName, userName, deptId);
				//request.getRequestDispatcher("/admin/manage-dept.jsp");			
				///AdminController/managedept
				//response.sendRedirect("AdminController/managedept");
				response.sendRedirect("/GrievanceSyatem/AdminController/managedept");

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
