package com.grievance.service;

import com.grievance.model.User;

public interface UserI {

	public static final String userId = "U"+Math.round(Math.random() * 9999);
	public User login(String email, String password) throws Exception;
}
