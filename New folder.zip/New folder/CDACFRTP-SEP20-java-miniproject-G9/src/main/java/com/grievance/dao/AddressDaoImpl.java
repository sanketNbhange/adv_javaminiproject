package com.grievance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.grievance.dbutil.DbUtil;
import com.grievance.model.Address;

public class AddressDaoImpl implements AddressDaoI {

	public int addAddress(Address address) throws Exception {
		String query = "INSERT INTO address values(?,?,?,?,?)";
		Connection con = DbUtil.getConnection();
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1, address.getAddressId());
		ps.setString(2, address.getHouseNo());
		ps.setString(3, address.getLandMark());
		ps.setString(4, address.getPincode());
		ps.setString(5, address.getUserId());
		return ps.executeUpdate();
	}

}
