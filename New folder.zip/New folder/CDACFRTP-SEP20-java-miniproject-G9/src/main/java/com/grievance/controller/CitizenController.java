package com.grievance.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.grievance.model.Complaint;
import com.grievance.model.Department;
import com.grievance.service.CitizenService;
import com.grievance.service.ComplaintI;
import com.grievance.service.ComplaintService;
import com.grievance.service.DepartmentI;
import com.grievance.service.DepartmentService;

import java.io.InputStream;
import java.util.List;

import javax.servlet.http.Part;

@MultipartConfig( fileSizeThreshold = 1024*1024,maxFileSize = 1024*1024*5, maxRequestSize = 1024*1024*5*5)   // upload file's size up to 16MB
public class CitizenController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CitizenService citService = new CitizenService();
	ComplaintI complaintService = new ComplaintService();
	DepartmentI deptService = new DepartmentService();   

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	
		String path = request.getPathInfo();
		
		//
		if (path.equals("/adduser")) {
			try {
				System.out.println("DDDDDDDDDDDDDDDDDD");
				String name = request.getParameter("name");
				String email = request.getParameter("email");
				String password = request.getParameter("password");
				String mobileNumber = request.getParameter("mobileNo");
				String houseNo = request.getParameter("houseNo");
				String landMark = request.getParameter("landmark");
				String pincode = request.getParameter("pincode");
				System.out.println(pincode);
				citService.registerCitizen(name, email, password, mobileNumber, houseNo, landMark, pincode);
				System.out.println("DDDDDDDDDDDDDDDDDD");
				response.sendRedirect("/GrievanceSyatem/index.jsp");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		//
		if (path.equals("/addComplaint")) {

			System.out.println(" inside add complaint ");

			Part filePart = request.getPart("screenshot");
			InputStream inputStream = filePart.getInputStream();
			byte[] doc = new byte[inputStream.available()];
			String complaintMsg = request.getParameter("complaintmsg");
			System.out.println(complaintMsg);
			System.out.println(doc);
			getServletContext().getRequestDispatcher("/Message.jsp").forward(request, response);

			try {
				complaintService.addComplaint(complaintMsg, doc, request.getParameter("deptId"));
			} catch (Exception e) {

				e.printStackTrace();
			}
		}
		
		//
		else if(path.equals("/registerComplaint")) {
			System.out.println("hii register");
			
			try {
				  List<Department> listDept = this.deptService.getALLDepartment();
				 // System.out.println(listDept);
				request.setAttribute("department",listDept );
				getServletContext().getRequestDispatcher("/citizen/register-complaint.jsp").forward(request, response);
				
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			
			
			
		}
		else if(path.equals("/listComplaint")) {
			System.out.println("hii register");
			
			try {
				
//				  List<Complaint> complaints = citService.getAllCitizenComplaints("");
//				 // System.out.println(listDept);
//				request.setAttribute("department",listDept );
//				getServletContext().getRequestDispatcher("/citizen/register-complaint.jsp").forward(request, response);
				
			} catch (Exception e) {
				
				e.printStackTrace();
			}
			
			
			
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("/CitizenController/*");
		doGet(request, response);
	}
	//	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	//			throws ServletException, IOException {
	//		doGet(request, response);
	//		String path = request.getPathInfo();
	//		System.out.println("hii");
	//
	//		Part filePart = request.getPart("screenshot");
	//		InputStream inputStream = filePart.getInputStream();
	//		byte[] doc = new byte[inputStream.available()];
	//		String complaintMsg = request.getParameter("complaintmsg");
	//		System.out.println(complaintMsg);
	//		System.out.println(doc);
	//
	//		try {
	//			complaintService.addComplaint(complaintMsg, doc, "D101");
	//		} catch (Exception e) {
	//			// TODO Auto-generated catch block
	//			e.printStackTrace();
	//
	//		}

	//            // sets the message in request scope
	//            request.setAttribute("Message", message);
	//             
	//            // forwards to the message page
	//	getServletContext().getRequestDispatcher("/Message.jsp").forward(request, response);
	// }
	//}

}
