package com.grievance.service;

import com.grievance.dao.UserDaoI;
import com.grievance.dao.UserDaoImpl;
import com.grievance.model.User;

public class UserService implements UserI {

	UserDaoI userDao = new UserDaoImpl();
	
	@Override
	public User login(String email, String password) throws Exception {
		User user = userDao.loginUser(email, password);
		return user;
	}

}
