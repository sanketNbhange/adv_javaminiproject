package com.grievance.dao;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.grievance.dbutil.DbUtil;
import com.grievance.dto.ComplaintDto;
import com.grievance.model.Complaint;


public class ComplaintDaoImpl implements ComplaintDaoI{
	
	java.util.Date date=new java.util.Date();
	
	java.sql.Date sqlDate=new java.sql.Date(date.getTime());
	java.sql.Timestamp sqlTime=new java.sql.Timestamp(date.getTime());
	
	@Override
	public int registerComplaint(Complaint complaint) throws Exception {
		String query = "INSERT INTO complaint values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		System.out.println(complaint.toString());
		Connection con = DbUtil.getConnection();
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1, complaint.getComplaintId());
		ps.setString(2, complaint.getComplaintMsg());
		ps.setBytes(3, complaint.getDocs());
		ps.setString(4, "0");
		ps.setDate(5,  sqlDate);
		ps.setDate(6,  sqlDate);
		ps.setString(7, complaint.getComplaintStatus());
		ps.setString(8, complaint.getUserId());
		ps.setString(9, complaint.getDeptId());
		ps.setString(10, complaint.getAddressId());
		ps.setString(11, "0");
		ps.setString(12, "0");
		ps.setTimestamp(13, sqlTime);
		return ps.executeUpdate();
	}

	@Override
	public List<ComplaintDto>  getAllComplaintByDeptId(String deptid) throws Exception {
		String sql = "select complaint.complaintid ,user.name,\r\n"
				+ "user.email,complaint.complaintmsg,complaint.screenshot,complaint.complaintdate,complaint.updatecount\r\n"
				+ "from complaint inner join user on complaint.userid = user.userid\r\n"
				+ "where complaint.deptid =?" ;
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, deptid);
		ResultSet rs = ps.executeQuery();

		List<ComplaintDto> complaintInfo = new ArrayList<ComplaintDto>();
		while (rs.next()) {
			
			complaintInfo.add(new ComplaintDto(rs.getString(1), rs.getString(2),rs.getString(3), rs.getString(4),
					rs.getBytes(5),rs.getDate(6).toLocalDate(),rs.getInt(7)));
		}
		return complaintInfo;
	}

}
