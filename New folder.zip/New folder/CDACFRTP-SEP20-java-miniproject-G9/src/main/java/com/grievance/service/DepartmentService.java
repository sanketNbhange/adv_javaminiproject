package com.grievance.service;

import java.util.List;

import com.grievance.dao.AdminDao;
import com.grievance.dao.AdminDaoImpl;
import com.grievance.dao.DepartDaoimpl;
import com.grievance.dao.DepartmentDao;
import com.grievance.dao.EmployeeDaoI;
import com.grievance.dao.EmployeeDaoImpl;
import com.grievance.dao.UserDaoI;
import com.grievance.dao.UserDaoImpl;
import com.grievance.dto.DepartmentHeadDto;
import com.grievance.model.Department;
import com.grievance.model.User;
public class DepartmentService implements DepartmentI{

	EmployeeDaoI empDao =new EmployeeDaoImpl();
	DepartmentDao deptDao = new DepartDaoimpl();
	UserDaoI userDao = new UserDaoImpl();
	AdminDao adminDao = new AdminDaoImpl();
	public String registerDepartment(String deptName, String userName) throws Exception {
		Department department = null;

		User user = empDao.getUserByName(userName);
		System.out.println(user.toString());
		department = new Department(DepartmentI.deptId, deptName, user.getUserId());
		int status = deptDao.addDepartment(department);
		System.out.println(status);
		if(status == 1)
		{
			return userName;
		}
		else
		{
			throw new Exception("unable to store in datbase please try again");
		}
	}

	@Override
	public int deleteDepartment(String deptid) throws Exception {
		return deptDao.deleteDepartment(deptid);
	}

	@Override
	public int updateDepartment(String deptName, String userName, String deptId) throws Exception {
		Department department = new Department();
		User user = empDao.getUserByName(userName);
		System.out.println(user.toString());
		department = new Department(deptId,deptName, user.getUserId());
		return deptDao.updateDepartment(department);
	}

	@Override
	public List<Department> getALLDepartment() throws Exception {
		return new AdminDaoImpl().getAllDepartment();
	}

	public Department getDepartmentById(String deptId) throws Exception {
		Department department = new Department();
		department = deptDao.getDepartmentById(deptId);
		return department;
	}

	
}
