package com.grievance.service;

public interface AddressI {
	public static final String addressId = "A"+Math.round(Math.random() * 9999);
}
