package com.grievance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.grievance.dbutil.DbUtil;
import com.grievance.model.Complaint;
import com.grievance.model.User;

public class CitizenDaoImpl implements CitizenDaoI{

	
	//addNewUser In database
	public String addCitizen(User user) throws Exception {
		String query= "insert into user values(?,?,?,?,?,?)";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(query);

		ps.setString(1, user.getUserId());
		ps.setString(2, user.getName());
		ps.setString(3, user.getEmail());
		ps.setString(4, user.getMobileNo());
		ps.setString(5, user.getPassword());
		ps.setString(6, user.getRole());
		ps.executeUpdate();
		return user.getUserId();
	}

	@Override
	public List<Complaint> getAllCitizenComplaint(String userId) throws Exception {
		String sql = "SELECT * FROM complaint where userid = ?" ;
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, userId);
		ResultSet rs = ps.executeQuery();

		List<Complaint> complaints = new ArrayList<Complaint>();
		while (rs.next()) {
			
			complaints.add(new Complaint(rs.getString(1), rs.getString(1), rs.getBytes(3), rs.getInt(4),
					rs.getDate(5).toLocalDate(), rs.getDate(6).toLocalDate(), rs.getString(7), rs.getString(1), 
					rs.getString(1),  rs.getDate(6).toLocalDate(), rs.getString(1), rs.getString(1), rs.getString(1)));
		}
		return complaints;
	}

	@Override
	public int updateCitizenRemark(String complaintId, String message) throws Exception {
		String sql = "UPDATE userremark = ? from complaint where complaintid = ? " ;
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, message);
		ps.setString(2, complaintId);
		return ps.executeUpdate();
	}
	
	
	


	//get user by email and password
//	public User getCitizen(String email, String password) throws Exception {
//		String query = "select * from user where email=? and password=?";
//		Connection connection = DbUtil.getConnection();
//		PreparedStatement ps = connection.prepareStatement(query);
//		ps.setString(1, email);
//		ps.setString(2, password);
//		ResultSet rs = ps.executeQuery();
//		User  user = null;
//		if(rs.next()) {
//			user = new User(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
//		}
//		return user;
//	}

}
