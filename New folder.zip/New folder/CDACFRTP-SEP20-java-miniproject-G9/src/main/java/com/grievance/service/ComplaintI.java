package com.grievance.service;

import java.time.LocalDate;

public interface ComplaintI {
	
	public static final String complaintId = "C"+Math.round(Math.random() * 9999);
	public String addComplaint(String complaintMsg,  byte[] docs, String deptId) throws Exception;
}
