package com.grievance.dao;

import java.util.List;

import com.grievance.model.User;

public interface UserDaoI {

	public User loginUser(String email,String password) throws Exception;
}
