package com.grievance.service;

import java.util.List;

import com.grievance.model.Complaint;

public interface CitizenI {

	public String registerCitizen(String name, String email, String password, String mobileNo,String houseNo, String landMark, String pincode) throws Exception;
	public List<Complaint> getAllCitizenComplaints(String userId) throws Exception;
}
