package com.grievance.service;

import java.util.List;

import com.grievance.dto.DepartmentHeadDto;
import com.grievance.model.Department;

public interface AdminI {

	public List<Department> getAllDepartment() throws Exception;
	public List<DepartmentHeadDto> getAllDepartmentInfo() throws Exception;
}
