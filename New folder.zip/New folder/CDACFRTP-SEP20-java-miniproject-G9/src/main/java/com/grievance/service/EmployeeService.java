package com.grievance.service;

import java.util.ArrayList;
import java.util.List;

import com.grievance.dao.ComplaintDaoImpl;
import com.grievance.dao.EmployeeDaoI;
import com.grievance.dao.EmployeeDaoImpl;
import com.grievance.dto.ComplaintDto;
import com.grievance.model.User;

public class EmployeeService implements EmployeeI {
	EmployeeDaoI employeeDao = new EmployeeDaoImpl();
	public String registerEmployee(String name, String email, String password, String mobileNo, String role) throws Exception {
		User user = new  User(UserI.userId, name, email, password, mobileNo, role);
		int status = employeeDao.addEmployee(user);
		if(status == 1)
		{
			return name;
		}
		else
		{
			throw new Exception("Employee cannot create please try again");
		}
	}
	@Override
	public List<User> getAllFreeDeptHead() throws Exception {
		
		List<User> users = new ArrayList<User>();
		users = employeeDao.getAllFreeDeptHead();
		return users;
	}
	@Override
	public List<ComplaintDto> getAllComplaintsBtDeptId(String deptid) throws Exception {
		
		return new ComplaintDaoImpl().getAllComplaintByDeptId(deptid);
	}
	
	

}
