package com.grievance.dao;

import java.util.List;

import com.grievance.model.Complaint;
import com.grievance.model.User;

public interface EmployeeDaoI {

	public User getUserByName(String name) throws Exception;
	public int addEmployee(User user) throws Exception;
	public List<User> getAllFreeDeptHead() throws Exception;
	public List<Complaint> getAllComplaintById(String deptid) throws Exception;
	


}
